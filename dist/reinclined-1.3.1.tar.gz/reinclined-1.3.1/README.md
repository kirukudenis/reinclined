###  Clone from [ui-automation-tools-mbt](https://github.com/rakutentech/ui-automation-tools-mbt) will finally be merged back to that package. This is for testing purposes.

